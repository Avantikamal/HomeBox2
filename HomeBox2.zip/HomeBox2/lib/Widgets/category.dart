class Category{
  String image;
  String category;

  Category({this.image,this.category});

  void setImage(String imagePath){
    image=imagePath;
  }
   void setCategory(String Category){
    category=Category;
   }
  String getImage(){
     return image;

  }
  String getCategory(){
    return category;

  }

}


List<Category> single(){

  List<Category> single=new List<Category>();

  Category category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);


  category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);


  category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);


  category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);


  category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);


  category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);


  category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new Category();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);




  return single;


}