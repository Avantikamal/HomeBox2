class SubCategory{
  String image;
  String category;

  SubCategory({this.image,this.category});

  void setImage(String imagePath){
    image=imagePath;
  }
  void setCategory(String Category){
    category=Category;
  }
  String getImage(){
    return image;

  }
  String getCategory(){
    return category;

  }

}


List<SubCategory> single(){

  List<SubCategory> single=new List<SubCategory>();

  SubCategory category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);


  category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);


  category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);


  category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);


  category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);


  category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);


  category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);

  category=new SubCategory();
  category.setImage('assets/images/category1.png');
  category.setCategory('Fruits');
  single.add(category);




  return single;


}