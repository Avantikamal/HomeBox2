import 'package:flutter/material.dart';
import 'package:homebox/models/order.dart';
 import 'package:shared_preferences/shared_preferences.dart';
import 'package:scoped_model/scoped_model.dart';
import 'package:homebox/models/line_item.dart';
 mixin CartModel on Model{
   Order order;
   Map<dynamic, dynamic> lineItemObject = Map();

   List<LineItem> _lineItems = [];
   List<LineItem> get lineItems {
     return List.from(_lineItems);
   }
   bool _isLoading = false;
   bool get isLoading {
     return _isLoading;
   }
   void setLoading(bool loading) {
     _isLoading = loading;
     notifyListeners();
   }
   void removeProduct(int lineItemId) async {
     final SharedPreferences prefs = await SharedPreferences.getInstance();
     _isLoading = true;
     _lineItems.clear();
     notifyListeners();

   }


   void addProduct({int variantId, int quantity}) async {
     final SharedPreferences prefs = await SharedPreferences.getInstance();
     print("quantity $quantity");

     _lineItems.clear();
     notifyListeners();
     final String orderToken = prefs.getString('orderToken');

     if (orderToken != null) {
       createNewLineItem(variantId, quantity);
     } else {
       createNewOrder(variantId, quantity);
     }
     notifyListeners();
   }
   void createNewOrder(int variantId, int quantity) async {
//     Map<String, String> headers = await getHeaders();
//     Map<dynamic, dynamic> responseBody;
//     Map<dynamic, dynamic> orderParams = Map();
     final SharedPreferences prefs = await SharedPreferences.getInstance();

//     orderParams = {
//       'order': {
//         'line_items': {
//           '0': {'variant_id': variantId, 'quantity': quantity}
//         }
//       }
//     };

   }
   void createNewLineItem(int variantId, int quantity) async {

     final SharedPreferences prefs = await SharedPreferences.getInstance();
//     Map<String, String> headers = await getHeaders();

     lineItemObject = {
       "line_item": {"variant_id": variantId, "quantity": quantity}
     };

   }





 }