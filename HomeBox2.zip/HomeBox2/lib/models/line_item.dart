class LineItem {
  final int id;
  int quantity;
  final String total;
  final String displayAmount;
  LineItem(
      {this.displayAmount,
        this.id,
        this.quantity,
        this.total,
      });
}
