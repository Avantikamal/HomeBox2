class Category {
  final String name;
  final String image;



  Category({this.name, this.image});
}
