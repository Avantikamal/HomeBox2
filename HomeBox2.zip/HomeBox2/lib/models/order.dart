import 'package:homebox/models/line_item.dart';



class Order {
  final String total;
  final int id;
  final String itemTotal;
  final String displayTotal;
  final String displaySubTotal;
  final List<LineItem> lineItems;
  int totalQuantity;
  String shipTotal;
  String state;
  String completedAt, imageUrl, number;
  Address shipAddress;
  final String  paymentMethod;

  Order(
      {this.total,
        this.id,
        this.completedAt,
        this.imageUrl,
        this.number,
        this.displayTotal,
        this.displaySubTotal,
        this.itemTotal,
        this.lineItems,
        this.shipTotal,
        this.totalQuantity,
        this.state,
        this.shipAddress,
        this.paymentMethod,
        });
}
class Address {
  final String firstName;
  final String lastName;
  final String stateName;
  final String stateAbbr;
  final String address1;
  final String address2;
  final String city;
  final String mobile;
  final String pincode;
  final int stateId;
  final int id;

  Address(
      {this.id,
        this.firstName,
        this.address1,
        this.address2,
        this.city,
        this.lastName,
        this.mobile,
        this.pincode,
        this.stateName,
        this.stateAbbr,
        this.stateId});
}
