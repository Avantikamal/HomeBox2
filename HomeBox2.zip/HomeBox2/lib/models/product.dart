

class Product {
  final String title;
  final int price;
  final int discountPrice;
  final String categoryName;
  final String subCategoryName;
  final String description;

  Product({this.title,
    this.price,
    this.discountPrice,
    this.categoryName,
    this.subCategoryName,
    this.description});
}