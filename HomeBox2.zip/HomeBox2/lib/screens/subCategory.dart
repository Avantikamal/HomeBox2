import 'package:flutter/material.dart';
import 'package:homebox/Widgets/sub_category.dart';
import 'package:homebox/screens/payment.dart';
import 'package:homebox/screens/product_details.dart';

class Subcategory extends StatefulWidget {
  @override
  _SubcategoryState createState() => _SubcategoryState();
}

class _SubcategoryState extends State<Subcategory> {


  List<SubCategory> mySubCategories=new List<SubCategory>();
  int index=0;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    mySubCategories=single();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
body: SafeArea(
  child:   Stack(
    children: <Widget>[
      Container(
  
        height: MediaQuery.of(context).size.height,
  
        width: double.infinity,
  
        color: Colors.white,
  
      ),
  
      Container(
  
        height: 230.0,
  
        width: double.infinity,
  
        color: Colors.red,
  
      ),
  
      Padding(
  
        padding: EdgeInsets.only(top: 35.0),
  
        child: IconButton(
  
            alignment: Alignment.topLeft,
  
            icon: Icon(Icons.arrow_back_ios,
  
            color: Colors.white,),
  
            onPressed: () {
              Navigator.pop(context);
            }),
  
      ),
  
      Positioned(
  
          top: 130.0,
  
          left: 25.0,
  
          child: Padding(
  
            padding: const EdgeInsets.only(left:8.0),
  
            child: Text(
  
              'Fruits',
  
              style: TextStyle(
  
                color: Colors.white,
  
                  fontSize: 40.0, fontWeight: FontWeight.bold),
  
            ),
  
          )),
                         //search bar is remaining
  
      Positioned(

        top: 155.0,

        left: 2.0,
       child:  Container(
         width: MediaQuery.of(context).size.width-45.0,
         margin:
         const EdgeInsets.only(top: 48, right: 20, left: 20),
         child: TextField(

           decoration: InputDecoration(
             fillColor: Colors.white,
             hintText: "Search",
             enabledBorder:  OutlineInputBorder(
                 borderRadius: BorderRadius.all(Radius.circular(4)),
                 borderSide: BorderSide(color: Colors.grey)).copyWith(
                 borderSide: BorderSide(color: Colors.grey),
                 borderRadius:
                 BorderRadius.all(Radius.circular(24))),
             contentPadding: EdgeInsets.only(
                 top: 16, left: 12, right: 12, bottom: 8),
             border:  OutlineInputBorder(
                 borderRadius: BorderRadius.all(Radius.circular(4)),
                 borderSide: BorderSide(color: Colors.grey)).copyWith(
                 borderSide: BorderSide(color: Colors.white),
                 borderRadius:
                 BorderRadius.all(Radius.circular(24))),
             enabled: true,
             filled: true,
           ),
         ),
       ),
      ),



      Padding(
        padding: const EdgeInsets.only(top: 270.0),
        child: CustomScrollView(
            primary: false,
            slivers: <Widget>[
        SliverPadding(
        padding: const EdgeInsets.all(20),
        sliver: SliverGrid.count(
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          crossAxisCount: 3,
          children: <Widget>[

            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),

            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),

            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),

            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),

            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),
            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),
            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),
            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),
            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),
            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),
            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),
            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),
            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),
            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),
            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),

            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),
            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),  Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),
            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),
            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),
            Single_Subcategory(
              image: mySubCategories[0].getImage(),
              category: mySubCategories[0].getCategory(),
            ),




          ]
        )
        )
              ]
        ),
      )
    ],
  
  ),
),

    );
  }
}

class Single_Subcategory extends StatelessWidget {

  String image;
  String category;

  Single_Subcategory({this.image,this.category});


  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: (){
        Navigator.push(context, MaterialPageRoute(builder: (context) {
          return Product_details();
        } ));
      },
//      onTap: () =>
//          Navigator.push(context, MaterialPageRoute(
//              builder: (context) => Product_details())),
      child: Column(
        children: <Widget>[
          Container(
            height: 80.0,
            width: 95.0,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                image: DecorationImage(image: AssetImage(image),
                    fit: BoxFit.cover)
            ),
            padding: EdgeInsets.only(left: 8.0,right: 8.0,bottom: 18.0),
            //child: Image.asset(image),
          ),
          SizedBox(height: 3.0,),
          Text(category),
        ],
      ),
    );
  }
}
