import 'package:flutter/material.dart';
import 'package:homebox/screens/Order_confirmation.dart';

import 'Checkout.dart';
class Value {

  final String _value;
  Value(this._value);
}

class Payment extends StatefulWidget {
  @override
  _PaymentState createState() => _PaymentState();
}

class _PaymentState extends State<Payment> {

  _verticalDivider() => Container(
    padding: EdgeInsets.all(2.0),
  );

  _verticalD() => Container(
    margin: EdgeInsets.only(left: 5.0),
  );


  int radioValue = 0;
  void handleRadioValueChanged(int value) {
    setState(() {
      radioValue = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0.0,
        backgroundColor: Colors.white,
        leading: IconButton(icon: Icon(Icons.arrow_back_ios,
          color: Colors.black,
        ),
        onPressed: ()=>Navigator.push(context, MaterialPageRoute(
          builder: (context) => Checkout(),
        )),
      ),),

      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(left:20.0),
            child: Text('Pay ₹120.00',style: TextStyle(
              color: Colors.red,
              fontWeight: FontWeight.w700,
              fontSize: 25.0
            ),),
          ),
          SizedBox(height: 30.0),
        Padding(
          padding: const EdgeInsets.only(left:24.0,top: 20.0),
          child: Text('Choose your payment method',
          textAlign: TextAlign.left,style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.w700,
            fontSize: 20.0
      ),),
        ),
      SizedBox(height: 10.0),
    Padding(
      padding: const EdgeInsets.only(left:10.0,right: 10.0),
      child: Column(
        children: <Widget>[
          Card(
            color: Colors.red.shade50,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Icon(
                  const IconData(0xe900,
                      fontFamily: 'icomoon'),
                  color: Colors.white,
                  size: 15.0,
                ),
                Text('PayPal',style: TextStyle(color: Colors.red),),
                IconButton(icon: Icon(Icons.arrow_forward_ios,color: Colors.red,),)
              ],
            ),
          ),
SizedBox(height: 10.0,),
          Card(
            color: Colors.red.shade50,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Icon(
                  const IconData(0xe900,
                      fontFamily: 'icomoon'),
                  color: Colors.white,
                  size: 15.0,
                ),
                Text('Google Pay',style: TextStyle(color: Colors.red),),
                IconButton(icon: Icon(Icons.arrow_forward_ios,color: Colors.red,),)
              ],
            ),
          ),
          SizedBox(height: 10.0,),
          Card(
            color: Colors.red.shade50,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Icon(
                  const IconData(0xe900,
                      fontFamily: 'icomoon'),
                  color: Colors.white,
                  size: 15.0,
                ),
                Text('PhonePe',style: TextStyle(color: Colors.red),),
                IconButton(icon: Icon(Icons.arrow_forward_ios,color: Colors.red,),)
              ],
            ),
          )
,SizedBox(height: 10.0,),
          Card(
            color: Colors.red.shade50,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Icon(
                  const IconData(0xe900,
                      fontFamily: 'icomoon'),
                  color: Colors.white,
                  size: 15.0,
                ),
                Text('Paytm',style: TextStyle(color: Colors.red),),
                IconButton(icon: Icon(Icons.arrow_forward_ios,color: Colors.red,),)
              ],
            ),
          )
          ,SizedBox(height: 10.0,),
          Card(
            color: Colors.red.shade50,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Icon(
                  const IconData(0xe900,
                      fontFamily: 'icomoon'),
                  color: Colors.white,
                  size: 15.0,
                ),
                Text('Cash on Delivery',style: TextStyle(color: Colors.red),),
                IconButton(icon: Icon(Icons.arrow_forward_ios,color: Colors.red,),)
              ],
            ),
          ),
SizedBox(height: 50.0,),
Container(
  width: 170.0,
  decoration: BoxDecoration(
    color: Colors.red,
    borderRadius: BorderRadius.circular(20.0)
  ), 
  child: FlatButton(onPressed: ()=>
      Navigator.push(context,
          MaterialPageRoute(builder: (context)=> Order_Confirmation())),
      child: Text('Confirm',style: TextStyle(color: Colors.white),)),
)


//        Card(
//        child: Column(
//        children: <Widget>[
//        Container(
//        padding: EdgeInsets.only(left: 10.0),
//        child: Row(
//        mainAxisSize: MainAxisSize.max,
//        mainAxisAlignment: MainAxisAlignment.spaceBetween,
//        children: <Widget>[
//        Text("Wallet / UPI",
//        maxLines: 10,
//        style: TextStyle(
//        fontSize: 15.0, color: Colors.black)),
//        Radio<int>(
//        value: 0,
//        groupValue: 0,
//        onChanged: null),
//        ],
//        ),
//        ),
//        Divider(),
//        _verticalD(),
//        Container(
//        padding: EdgeInsets.only(left: 10.0),
//        child: Row(
//        mainAxisSize: MainAxisSize.max,
//        mainAxisAlignment: MainAxisAlignment.spaceBetween,
//        children: <Widget>[
//        Text("Net Banking",
//        maxLines: 10,
//        style: TextStyle(
//        fontSize: 15.0, color: Colors.black)),
//        Radio<int>(
//        value: 0,
//        groupValue: radioValue,
//        onChanged: null),
//        ],
//        )),
//        Divider(),
//        _verticalD(),
//        Container(
//        padding: EdgeInsets.only(left: 10.0),
//        child: Row(
//        mainAxisSize: MainAxisSize.max,
//        mainAxisAlignment: MainAxisAlignment.spaceBetween,
//        children: <Widget>[
//        //  Container(child: Image.asset('assets/logo/credit_card.png')),
//        Text("Credit / Debit / ATM Card",
//        maxLines: 10,
//        style: TextStyle(
//        fontSize: 15.0, color: Colors.black)),
//        Radio<int>(
//        value: 0,
//        groupValue: 0,
//        onChanged: handleRadioValueChanged),
//        ],
//        )),
//        Divider(),
//        _verticalD(),
//        Container(
//        padding: EdgeInsets.only(left: 10.0),
//        child: Row(
//        mainAxisSize: MainAxisSize.max,
//        mainAxisAlignment: MainAxisAlignment.spaceBetween,
//        children: <Widget>[
//        Text("Cash on Delivery",
//        maxLines: 10,
//        style: TextStyle(
//        fontSize: 15.0, color: Colors.black)),
//        Radio<int>(
//        value: 0,
//        groupValue: 0,
//        onChanged: null),
//        ],
//        )),
//        Divider(),
//        ],
//        ),
//        ),
        ],
      ),
    ),
//    Padding(
//      padding: const EdgeInsets.only(top: 150.0),
//      child: Container(
//      alignment: Alignment.bottomLeft,
//      height: 50.0,
//      child: Row(
//      mainAxisSize: MainAxisSize.max,
//
//      children: <Widget>[
//      IconButton(icon: Icon(Icons.info), onPressed: null),
//      Text(
//      'Total :',
//      style: TextStyle(
//      fontSize: 17.0,
//      color: Colors.black,
//      fontWeight: FontWeight.bold),
//      ),
//      Text(
//      '\₹ 524',
//      style: TextStyle(fontSize: 17.0, color: Colors.green),
//      ),
////          Column(
////            children: <Widget>[
////              RadioListTile(
////                selected: false,
////
////                title: Text("Credit/Debit Card"),
////                onChanged: (value){},
////              ),
////              Divider(),
////              RadioListTile(
////                selected: false,
////
////                title: Text("Cash on Delivery"),
////                onChanged: (value){},
////              ),Divider(),
////              RadioListTile(
////                selected: false,
////
////                title: Text("Paypal"),
////                onChanged: (value){},
////              ),Divider(),
////              RadioListTile(
////                selected: false,
////
////                title: Text("Paytm"),
////                onChanged: (value){},
////              ),Divider(),
////              RadioListTile(
////                selected: false,
////
////                title: Text("Google Wallet"),
////                onChanged: (value){},
////              ),
////
////            ],
////          ),
//         SizedBox(width: 90.0,),
//        Container(
//         width: 150.0,
//          child: FlatButton(
//            color: Colors.red,
//            onPressed: ()=>
//                Navigator.push(context, MaterialPageRoute(
//                  builder: (context) => Order_Confirmation(),
//                )),
//            child: Text("Pay",
//              textAlign: TextAlign.center,
//              style: TextStyle(
//                  color: Colors.white
//              ),),
//          ),
//        ),
//
//      ]
//      )
//      ),
//    )
        ]
      )
      );
  }
}
