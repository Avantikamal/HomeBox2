//import 'package:flutter/material.dart';
//class SlideDots extends StatelessWidget {
//  @override
//  Widget build(BuildContext context) {
//    return AnimatedContainer(
//        duration: null);
//  }
//}
