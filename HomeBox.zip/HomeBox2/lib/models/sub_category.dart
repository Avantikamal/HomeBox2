import 'package:homebox/models/product.dart';
class SubCategory {
  final String name;
  final String image;
List<Product> product;


  SubCategory({this.name, this.image,this.product});

}