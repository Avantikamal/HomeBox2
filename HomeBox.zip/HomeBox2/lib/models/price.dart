class Price{
  final double price;
  final String wt;

  Price({this.price,this.wt});
}