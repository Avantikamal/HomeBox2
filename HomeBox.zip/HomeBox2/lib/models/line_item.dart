class LineItem {
  final String image;
  final String title;
  final int id;
  int quantity;
  final String total;

  LineItem(
      {this.image,

        this.title,
        this.id,
        this.quantity,
        this.total,
      });
}
