class User {
  String name;
  String email;
  Map shipAddress;
  User({this.email, this.name, this.shipAddress});
}
